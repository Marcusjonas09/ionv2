<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <strong>Course Petitions</strong>
                    <small>Administrator</small>
        </h1>
        <ol class="breadcrumb">
            <li class="active">Course Petitions</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-header">
                        <!-- <h3 class="box-title">Students</h3> -->

                        <div class="box-tools">
                            <div class="input-group input-group-sm" style="width: 150px;">
                                <!-- <input type="text" name="table_search" class="form-control pull-right" placeholder="Search">
                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div> -->
                            </div>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <thead>
                                <th>Petition ID</th>
                                <th>Course</th>
                                <th>Schedule</th>
                                <th>Professor</th>
                                <th>Status</th>
                                <th>Action</th>
                            </thead>
                            <tbody>
                                <?php foreach ($petitions as $petition) : ?>
                                    <tr>
                                        <td><?= $petition->petition_ID ?></td>
                                        <td><?= $petition->course_code ?></td>
                                        <td><?= $petition->schedule ?></td>
                                        <td><?= $petition->faculty_id ?></td>
                                        <td>
                                            <?php if ($petition->petition_status == 1) {
                                                echo "<span class ='label label-success'>Approved </span>";
                                            } else if ($petition->petition_status == 2) {
                                                echo "<span class ='label label-warning'>Pending</span>";
                                            } else {
                                                echo "<span class ='label label-danger'>Declined</span>";
                                            }
                                            ?></td>
                                        <td>
                                            <a href="<?= base_url() ?>Admin/show_petition/<?= $petition->petition_ID ?>/<?= $petition->course_code ?>" class="btn btn-warning btn-sm rounded"><i class="fa fa-eye"></i>&nbsp&nbsp VIEW</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
        </div>

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->