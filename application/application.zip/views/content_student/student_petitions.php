<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      <strong>Petition Courses</strong>
    </h1>
  </section>

  <!-- Main content -->
  <section class="content container-fluid">

    <!-- Submit Petition Form -->

    <!-- Horizontal Form -->
    <div class="box box-success">
      <div class="box-header with-border">
        <h3 class="box-title">Submit Petition</h3>
      </div>
      <!-- /.box-header -->
      <!-- form start -->
      <form class="form-horizontal" action="<?= base_url() ?>Student/submitPetition" method="POST">
        <div class="box-body">
          <?php if (validation_errors()) : ?>
            <div class="alert alert-warning alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <h4><i class="icon fa fa-warning"></i> Alert!</h4>
              <?php echo validation_errors(); ?>
            </div>
          <?php endif; ?>
          <div class="form-group">
            <label class="col-md-2 control-label">Course Code</label>

            <!-- <div class="col-md-9"> -->
            <!-- <input type="text" name="course_code" class="form-control" placeholder="Course Code"> -->
            <div class="form-group col-md-6">
              <select name="course_code" class="form-control select2">
                <?php foreach ($courses as $course) : ?>
                  <option value="<?= $course->course_code ?>"><?= $course->course_code . ' - ' . $course->course_title ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <input type="hidden" name="stud_number" value="<?= $this->session->acc_number ?>" class="form-control">
            <input type="hidden" name="date_submitted" value="<?= time() ?>" class="form-control">
            <!-- </div> -->
            <!-- <div class="col-sm-2"> -->
            <button type="submit" class="btn btn-success" style="margin-left:10px;">Submit</button>
            <!-- </div> -->
          </div>
        </div>
        <!-- /.box-body -->

      </form>
    </div>
    <!-- /.box -->

    <!-- Table showing all petitions related to this student account -->

    <div class="box box-success">
      <div class="box-header">
        <h3 class="box-title">All Petitions</h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <table id="petitionTable" class="table table-bordered table-striped">
          <thead>
            <th>Petition ID</th>
            <th>Course</th>
            <th>Schedule</th>
            <th>Professor</th>
            <th>Status</th>
            <th>Action</th>
          </thead>
          <tbody>

            <?php foreach ($petitions as $petition) : ?>
              <tr>
                <td><?= $petition->petition_ID ?></td>
                <td><?= $petition->course_code ?></td>
                <td><?= $petition->faculty_id ?></td>
                <td><?= $petition->schedule ?></td>
                <td>
                  <?php if ($petition->petition_status == 1) {
                      echo "<span class='label label-success'>Approved</span>";
                    } elseif ($petition->petition_status == 2) {
                      echo "<span class='label label-warning'>Pending</span>";
                    } else {
                      echo "<span class='label label-danger'>Denied</span>";
                    } ?>
                </td>
                <td>

                  <form action="<?= base_url() ?>Student/sign" method="POST">
                    <input name="stud_number" type="hidden" value="<?= $this->session->acc_number ?>">
                    <input name="course_code" type="hidden" value="<?= $petition->course_code ?>">
                    <a href="<?= base_url() ?>Student/petitionView/<?= $petition->petition_ID ?>/<?= $petition->course_code ?>" class="btn btn-warning btn-sm rounded"><i class="fa fa-eye"></i></a>
                    <button class="btn btn-success btn-sm rounded" type="submit"><i class="fa fa-pencil-square-o"></i></button>
                  </form>

                  <!-- <?php if ($student->acc_status) {
                            echo '<a href="' . base_url() . 'Admin/blockUser/' . $student->acc_number . '" class="btn btn-danger btn-sm rounded"><i class="fa fa-ban"></i></a>';
                          } else {
                            echo '<a href="' . base_url() . 'Admin/blockUser/' . $student->acc_number . '" class="btn btn-success btn-sm rounded"><i class="fa fa-check"></i></a>';
                          }; ?> -->


                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->

  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->