<?php
defined('BASEPATH') or exit('No direct script access allowed');

class CourseCard_model extends CI_Model
{

    public function fetchGrades()
    {
        $this->db->select('*');
        $this->db->where(array('course_status.curriculum_code' => $this->session->Curriculum_code, 'stud_number' => $this->session->acc_number));
        $this->db->from('course_status');
        $query = $this->db->get();
        return $query->result();
    }

    public function inputDebug($users)
    {
        echo '<pre>';
        print_r($users);
        die();
        echo '</pre>';
    }
}
