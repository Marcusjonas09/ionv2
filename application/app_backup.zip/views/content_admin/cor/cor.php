  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <strong>COR Revision</strong>
        <small>Administrator</small>
      </h1>
      <ol class="breadcrumb">
        <li class="active">COR Revision</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

      

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->