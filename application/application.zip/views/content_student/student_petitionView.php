<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <a class="navi" href="<?= base_url() ?>Student/petitions"><span class="fa fa-chevron-left"></span></a>&nbsp&nbsp<strong>Petition Form</strong>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <!-- Table showing all petitions related to this student account -->

        <div class="box box-success">
            <div class="box-header">
                <h3 class="box-title">Course Details</h3>
            </div>

            <table class="table">
                <tr>
                    <td>Course Code: <?= $petition->course_code ?></td>
                    <td>Date :</td>
                    <td>Status :<?php echo $status = $petition->petition_status ? " Approved" : " Pending"; ?></td>
                </tr>
                <tr>
                    <td>Section:</td>
                    <td>Course Description :</td>
                </tr>
                <tr>
                    <td>Schedule :</td>
                </tr>
                <tr>
                    <td>Time:</td>
                    <td>Day:</td>
                    <td>Room:</td>
                </tr>
                <tr>
                    <td>Faculty :</td>
                </tr>
            </table>

            <!-- /.box-header -->
            <div class="box-body">

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

        <div class="box box-success">
            <div class="box-header">
                <h3 class="box-title">Petitioners</h3>
            </div>

            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Student Number</th>
                    <th>Student Name</th>
                </thead>
                <tbody>
                    <?php foreach ($petitioners as $petitioner) : ?>
                        <tr>
                            <td><?= $petitioner->ID ?></td>
                            <td><?= $petitioner->stud_number ?></td>
                            <td><?= $petitioner->acc_fname . ' ' . $petitioner->acc_lname ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- /.box-header -->
            <div class="box-body">

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->