<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <strong><a class="navi" href="<?= base_url() ?>Superadmin/database"><span class="fa fa-chevron-left"></span>&nbsp&nbsp</a>Student Profile</strong>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">

    </section>
</div>
<!-- /.content-wrapper -->