<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Student extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();

		$this->load->library('form_validation');

		$this->load->model('Account_model');
		$this->load->model('Curriculum_model');
		$this->load->model('CourseCard_model');
		$this->load->model('Courseflow_model');
		$this->load->model('Post_model');
		$this->load->model('Petition_model');
		$this->load->model('Notification_model');
		$this->load->model('Enrollment_model');
		$this->load->model('Academics_model');
		$this->load->model('Student_model');
		$this->load->helper('text');
	}

	public function notifications()
	{
		$data = $this->Notification_model->getNotifications();
		echo json_encode($data);
	}

	public function user_data_submit()
	{
		$data = array(
			'caption' => $this->input->post('caption'),
			'account_id' => $this->input->post('account_id')
		);

		//Either you can print value or you can send value to database
		echo json_encode($data);
	}

	// =======================================================================================
	// MAIN LINKS
	// =======================================================================================

	// | SIDEBAR LINKS |

	//DASHBOARD LINK
	public function index()
	{
		$data['stud_details'] = $this->Courseflow_model->studentDetails();
		$data['progress'] = $this->Curriculum_model->fetchCurriculum();
		$data['grades'] = $this->CourseCard_model->fetchGrades();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_dashboard', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//ANNOUNCEMENT LINK
	public function announcements()
	{
		$year = $this->uri->segment(3);
		$month = $this->uri->segment(4);
		$prefs = array(
			'start_day'    => 'saturday',
			'month_type'   => 'long',
			'day_type'     => 'short',
			'show_next_prev'  => TRUE,
			'next_prev_url'   => 'http://localhost/ION/Student/announcements/'
		);


		$prefs['template'] = '

		        {table_open}<table class="table text-center" border="0" cellpadding="0" cellspacing="0">{/table_open}

		        {heading_row_start}<tr>{/heading_row_start}

		        {heading_previous_cell}<th><h3><strong><a href="{previous_url}" class="navi"><span class="fa fa-chevron-left"></span></a></strong></h3></th>{/heading_previous_cell}
		        {heading_title_cell}<th colspan="5"><h3><strong>{heading}</strong></h3></th>{/heading_title_cell}
		        {heading_next_cell}<th><h3><strong><a href="{next_url}" class="navi"><span class="fa fa-chevron-right"></span></a></strong></h3></th>{/heading_next_cell}

		        {heading_row_end}</tr>{/heading_row_end}

		        {week_row_start}<tr style="background-color:#efefef;">{/week_row_start}
		        {week_day_cell}<td>{week_day}</td>{/week_day_cell}
		        {week_row_end}</tr>{/week_row_end}

		        {cal_row_start}<tr>{/cal_row_start}
		        {cal_cell_start}<td>{/cal_cell_start}
		        {cal_cell_start_today}<td>{/cal_cell_start_today}
		        {cal_cell_start_other}<td class="other-month">{/cal_cell_start_other}

		        {cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
		        {cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}

		        {cal_cell_no_content}{day}{/cal_cell_no_content}
		        {cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}

		        {cal_cell_blank}&nbsp;{/cal_cell_blank}

		        {cal_cell_other}{day}{/cal_cel_other}

		        {cal_cell_end}</td>{/cal_cell_end}
		        {cal_cell_end_today}</td>{/cal_cell_end_today}
		        {cal_cell_end_other}</td>{/cal_cell_end_other}
		        {cal_row_end}</tr>{/cal_row_end}

		        {table_close}</table>{/table_close}
		';

		$this->load->library('calendar', $prefs);

		$data['my_calendar'] = $this->calendar->generate($year, $month);

		$data['announcements'] = $this->Post_model->fetchPosts();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_announcements', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	public function stud()
	{
		header("Access-Control-Allow-Origin: *");
		$data = $this->Courseflow_model->studentDetails();
		echo json_encode($data);
	}

	//CALENDAR LINK
	public function calendar()
	{
		$year = $this->uri->segment(3);
		$month = $this->uri->segment(4);
		$prefs = array(
			'start_day'    => 'saturday',
			'month_type'   => 'long',
			'day_type'     => 'short',
			'show_next_prev'  => TRUE,
			'next_prev_url'   => 'http://localhost/ION/Student/calendar/'
		);


		$prefs['template'] = '

		        {table_open}<table class="table text-center" border="0" cellpadding="0" cellspacing="0">{/table_open}

		        {heading_row_start}<tr>{/heading_row_start}

		        {heading_previous_cell}<th><h3><strong><a href="{previous_url}" class="navi"><span class="fa fa-chevron-left"></span></a></strong></h3></th>{/heading_previous_cell}
		        {heading_title_cell}<th colspan="5"><h3><strong>{heading}</strong></h3></th>{/heading_title_cell}
		        {heading_next_cell}<th><h3><strong><a href="{next_url}" class="navi"><span class="fa fa-chevron-right"></span></a></strong></h3></th>{/heading_next_cell}

		        {heading_row_end}</tr>{/heading_row_end}

		        {week_row_start}<tr style="background-color:#efefef;">{/week_row_start}
		        {week_day_cell}<td>{week_day}</td>{/week_day_cell}
		        {week_row_end}</tr>{/week_row_end}

		        {cal_row_start}<tr>{/cal_row_start}
		        {cal_cell_start}<td>{/cal_cell_start}
		        {cal_cell_start_today}<td>{/cal_cell_start_today}
		        {cal_cell_start_other}<td class="other-month">{/cal_cell_start_other}

		        {cal_cell_content}<a href="{content}">{day}</a>{/cal_cell_content}
		        {cal_cell_content_today}<div class="highlight"><a href="{content}">{day}</a></div>{/cal_cell_content_today}

		        {cal_cell_no_content}{day}{/cal_cell_no_content}
		        {cal_cell_no_content_today}<div class="highlight">{day}</div>{/cal_cell_no_content_today}

		        {cal_cell_blank}&nbsp;{/cal_cell_blank}

		        {cal_cell_other}{day}{/cal_cel_other}

		        {cal_cell_end}</td>{/cal_cell_end}
		        {cal_cell_end_today}</td>{/cal_cell_end_today}
		        {cal_cell_end_other}</td>{/cal_cell_end_other}
		        {cal_row_end}</tr>{/cal_row_end}

		        {table_close}</table>{/table_close}
		';

		$this->load->library('calendar', $prefs);

		$data['my_calendar'] = $this->calendar->generate($year, $month);
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_calendar', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	// =======================================================================================
	// MY ACCOUNT LINKS
	// =======================================================================================

	//PROFILE LINK
	public function Profile($studNumber)
	{
		$data['account'] = $this->Account_model->viewUser($studNumber);
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_profile', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//CURRICULUM LINK
	public function curriculum()
	{
		$data['curr'] = $this->Curriculum_model->fetchCurriculum();
		$data['grades'] = $this->CourseCard_model->fetchGrades();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_curriculum', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//COURSE CARD LINK
	public function course_card()
	{
		$data['terms'] = $this->Student_model->fetchTerm();
		$data['years'] = $this->Student_model->fetchYear();

		$term = $this->input->post('school_term');
		$year = $this->input->post('school_year');
		$stud_number = $this->session->acc_number;

		$data['course_card'] = $this->Student_model->fetchCourseCard($stud_number, $year, $term);
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_course_card', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer', $data);
	}

	//COR LINK
	public function cor()
	{
		$data['terms'] = $this->Student_model->fetchTerm();
		$data['years'] = $this->Student_model->fetchYear();

		$term = $this->input->post('school_term');
		$year = $this->input->post('school_year');
		$stud_number = $this->session->acc_number;

		$data['cor'] = $this->Student_model->fetchCOR($stud_number, $year, $term);

		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_COR', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//BALANCE INQUIRY LINK
	public function assessment()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_balance_inquiry');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	// =======================================================================================
	// ACADEMICS LINKS
	// =======================================================================================

	//BALANCE INQUIRY LINK
	public function parallel()
	{
		$data['parallel'] = $this->Academics_model->fetchParallel();
		$data['parallelCourse'] = $this->Academics_model->fetchParallelCourse();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_parallel_courses', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//BALANCE INQUIRY LINK
	public function offerings()
	{
		$data['offering'] = $this->Academics_model->fetchOffering();
		$data['offeringSched'] = $this->Academics_model->fetchOfferingSched();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_course_offerings', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	// =======================================================================================
	// SERVICES LINKS
	// =======================================================================================

	//ONLINE FACULTY EVALUATION LINK
	public function facultyEvaluation()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_curriculum');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}


	//ONLINE PUBLIC ACCESS CATALOGUE LINK
	public function OPAC()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_curriculum');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}


	//ONLINE FITNESS RESERVATION LINK
	public function fitnessReservation()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_curriculum');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//COURSE PETITIONING SYSTEM LINK
	public function petitions()
	{
		$data['petitions'] = $this->Petition_model->fetchPetitions();
		$data['courses'] = $this->Curriculum_model->fetchCourses();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_petitions', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//LOAD REVISION LINK
	public function revisions()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_Revision');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//OVERLOAD REQUEST LINK
	public function overloadRequest()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_Revision');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//UNDERLOAD REQUEST LINK
	public function underloadRequest()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_Revision');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//SIMUL REQUEST LINK
	public function simulRequest()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_simul');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}


	// =======================================================================================
	// OTHERS LINKS
	// =======================================================================================

	//STUDENT HANDBOOK LINK
	public function handbook()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_Revision');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	//CMO GUIDELINE LINK
	public function CMO()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_Revision');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	// =======================================================================================
	// OSES LINKS
	// =======================================================================================

	public function oses()
	{
		$data['offering'] = $this->Academics_model->fetchOffering();
		$data['offeringSched'] = $this->Academics_model->fetchOfferingSched();
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_oses', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	// =======================================================================================
	// DEBUG LINK
	// =======================================================================================

	public function debug()
	{
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/debug');

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	// =======================================================================================
	// VIEWLESS FUNCTIONS LINKS
	// =======================================================================================

	public function courseflow()
	{
		$data['curr'] = $this->Curriculum_model->fetchCurriculum();
		$data['grades'] = $this->CourseCard_model->fetchGrades();

		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/courseflow', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}



	public function submitPetition()
	{
		//here are the validation entry
		$this->form_validation->set_rules('course_code', 'Course Code', 'is_unique[petitions_tbl.course_code]|strip_tags|required');

		if ($this->form_validation->run() == FALSE) {
			$this->petitions();
		} else {
			$this->Petition_model->submitPetition($_POST);
			redirect('Student/petitions');
		}
	}

	public function petitionView($petitionID, $course_code)
	{
		$data['petition'] = $this->Petition_model->fetchPetition($petitionID);
		$data['petitioners'] = $this->Petition_model->fetchPetitioners($course_code);
		$this->load->view('includes_student/student_header');
		$this->load->view('includes_student/student_topnav');
		$this->load->view('includes_student/student_sidebar');

		$this->load->view('content_student/student_petitionView', $data);

		$this->load->view('includes_student/student_contentFooter');
		$this->load->view('includes_student/student_rightnav');
		$this->load->view('includes_student/student_footer');
	}

	public function sign()
	{
		$this->form_validation->set_rules('stud_number', 'Student Number', 'is_unique[petitioners_tbl.stud_number]|strip_tags|required');
		$this->form_validation->set_rules('course_code', 'Course Code', 'strip_tags|required');

		$course_code = $this->input->post('course_code');

		$row = $this->Petition_model->fetchNumberOfPetitioners($course_code);
		if ($row >= 40) {
			echo "<script>alert('no more space');</script>";
			redirect('Student/petitions');
		} else {
			if ($this->form_validation->run() == FALSE) {
				$this->petitions();
			} else {
				$this->Petition_model->signPetition();
				redirect('Student/petitions');
			}
		}
	}
}
