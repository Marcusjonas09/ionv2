<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <strong>Super Admin</strong>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <!-- <a class="btn btn-danger" href="<?= base_url() ?>SuperAdmin/empty_petitions">EMPTY PETITIONS</a> -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->