<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <a class="navi" href="<?= base_url() ?>Admin/course_petitions"><span class="fa fa-chevron-left"></span></a>&nbsp&nbsp<strong>Petition Form</strong>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url() ?>Admin/course_petitions"><i class="fa fa-dashboard"></i>Course Petitions</a></li>
            <li class="active">Petition</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <!-- Table showing all petitions related to this student account -->
        <?php if (validation_errors()) : ?>
            <div class="alert alert-warning alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <h4><i class="icon fa fa-warning"></i> Alert!</h4>
                <?php echo validation_errors(); ?>
            </div>
        <?php endif; ?>
        <div class="box box-success">
            <div class="box-header">
                <h3 class="box-title">Petition Status: </h3>
                <?php if ($petition->petition_status == 1) : ?>
                    <span class='label label-success'>Approved</span>
                <?php elseif ($petition->petition_status == 2) : ?>
                    <span class='label label-warning'>Pending</span>
                <?php else : ?>
                    <span class='label label-danger'>Declined</span>
                <?php endif; ?>
            </div>
            <div class="box-body">
                <form action="<?= base_url() ?>Admin/process_petition" method="POST">
                    <div class="container-fluid col-md-12">
                        <input name="petition_id" type="hidden" class="form-control" value="<?= $petition->petition_ID ?>">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Course Code: </label>
                                    <input name="course_code" type="text" class="form-control" readonly value="<?= $petition->course_code ?>">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Section</label>
                                    <input name="course_section" type="text" class="form-control" placeholder="Course section">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Date: </label>
                                    <input name="date_submitted" type="text" class="form-control" readonly value="<?= unix_to_human($petition->date_submitted) ?>">
                                    <input name="date_processed" type="hidden" class="form-control" readonly value="<?= time() ?>">
                                </div>
                            </div>
                        </div>


                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Course Description</label>
                                    <input name="course_description" type="text" class="form-control" placeholder="Course description">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Time</label>
                                    <input name="time" type="text" class="form-control" placeholder="Time">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Day</label>
                                    <input name="day" type="text" class="form-control" placeholder="Day">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label>Room</label>
                                    <input name="room" type="text" class="form-control" placeholder="Room">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Faculty</label>
                                        <input name="faculty" type="text" class="form-control" placeholder="Faculty">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php if ($petition->petition_status == 1 || $petition->petition_status == 0) : ?>
                            <a href="#" class="btn btn-success btn-sm rounded pull-right col-md-1 disabled" style="margin-right:10px;"><span class="fa fa-ban"></span>&nbsp Approve</a>
                            <a href="#" class="btn btn-danger btn-sm rounded pull-right col-md-1 disabled" style="margin-right:10px;"><span class="fa fa-ban"></span>&nbsp Decline</a>
                        <?php else : ?>
                            <button class="btn btn-success btn-sm rounded pull-right col-md-1 " type="submit" value="submit"><span class="fa fa-check"></span>&nbsp Approve</button>
                            <a href="<?= base_url() ?>Admin/decline_petition/<?= $petition->petition_ID ?>" class="btn btn-danger btn-sm rounded pull-right col-md-1" style="margin-right:10px;"><span class="fa fa-ban"></span>&nbsp Decline</a>
                        <?php endif ?>
                    </div>
                </form>
            </div>
        </div>

        <div class="box box-success">
            <div class="box-header">
                <h3 class="box-title">Petitioners</h3>
            </div>

            <table class="table">
                <thead>
                    <th>#</th>
                    <th>Student Number</th>
                    <th>Student Name</th>
                </thead>
                <tbody>
                    <?php foreach ($petitioners as $petitioner) : ?>
                        <tr>
                            <td><?= $petitioner->ID ?></td>
                            <td><?= $petitioner->stud_number ?></td>
                            <td><?= $petitioner->acc_fname . ' ' . $petitioner->acc_lname ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <!-- /.box-header -->
            <div class="box-body">

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->