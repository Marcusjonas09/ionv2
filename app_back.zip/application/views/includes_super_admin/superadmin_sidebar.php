 <!-- Left side column. contains the logo and sidebar -->
 <aside class="main-sidebar">

   <!-- sidebar: style can be found in sidebar.less -->
   <section class="sidebar">

     <!-- Sidebar user panel (optional) -->
     <div class="user-panel">
       <div class="pull-left image">
         <img src="<?= base_url() ?>dist/img/default_avatar.png" class="img-circle">
       </div>
       <div class="pull-left info">
         <p><?= $this->session->Firstname . ' ' . $this->session->Lastname ?></p>
         <!-- Status -->
         <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
       </div>
     </div>

     <!-- Sidebar Menu -->
     <ul class="sidebar-menu" data-widget="tree">
       <li class="header">MAIN NAVIGATION</li>

       <?php if ($this->session->access == 'superadmin') : ?>

         <li><a href="<?= base_url() ?>SuperAdmin/admin"><i class="fa fa-user"></i> <span>Admin Accounts</span></a></li>
         <!-- <li><a href="<?= base_url() ?>SuperAdmin/database"><i class="fa fa-user"></i> <span>Database</span></a></li> -->

       <?php endif; ?>

       <?php if ($this->session->access == 'admin') : ?>

         <li><a href="<?= base_url() ?>SuperAdmin/dashboard"><i class="fa fa-dashboard"></i><span>Dashboard</span></a></li>
         <!-- <li><a href="<?= base_url() ?>Admin/student_accounts"><i class="fa fa-user"></i> <span>Student Accounts</span></a></li> -->

       <?php endif; ?>

       <li><a href="<?= base_url() ?>Admin/school_announcements"><i class="fa fa-bullhorn"></i><span>School Announcements</span>
       <li><a href="<?= base_url() ?>Admin/academic_calendar"><i class="fa fa-calendar"></i><span>School Calendar</span></a></li>

       <li class="treeview">
         <a href="#">
           <i class="fa fa-share"></i> <span>Services</span>
           <span class="pull-right-container">
             <i class="fa fa-angle-left pull-right"></i>
           </span>
         </a>
         <ul class="treeview-menu">
           <li><a href="<?= base_url() ?>Admin/course_petitions"><i class="fa fa-file-text-o"></i><span>Course Petitions</span></a></li>
           <li><a href="<?= base_url() ?>Admin/faculty_evaluation"><i class="fa fa-file-text-o"></i><span>Faculty Evaluation</span></a></li>
           <li><a href="<?= base_url() ?>Admin/underload"><i class="fa fa-file-text-o"></i><span>Underload Requests</span></a></li>
           <li><a href="<?= base_url() ?>Admin/overload"><i class="fa fa-file-text-o"></i><span>Overload Requests</span></a></li>
           <li><a href="<?= base_url() ?>Admin/simul"><i class="fa fa-file-text-o"></i><span>Simul Requests</span></a></li>
         </ul>
       </li>

       <li><a href="<?= base_url() ?>SuperAdmin/school_parameters"><i class="fa fa-gear"></i> <span>School Parameters</span></a></li>
       <!-- <li><a href="<?= base_url() ?>SuperAdmin/faculty"><i class="fa fa-user"></i> <span>Faculty</span></a></li>
       <li><a href="<?= base_url() ?>SuperAdmin/student"><i class="fa fa-user"></i> <span>Student</span></a></li>
       <li><a href="<?= base_url() ?>SuperAdmin/course"><i class="fa fa-user"></i> <span>Course</span></a></li>
       <li><a href="<?= base_url() ?>SuperAdmin/laboratory"><i class="fa fa-user"></i> <span>Laboratory</span></a></li> -->
     </ul>
     <!-- /.sidebar-menu -->
   </section>
   <!-- /.sidebar -->
 </aside>