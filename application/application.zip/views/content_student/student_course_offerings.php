<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <strong>Course Offerings</strong>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
            <div class="box-header with-border">
                <form>
                    <div class="row container">
                        <h3 class="box-title pull-left"><strong>School Year: </strong></h3>
                        <div class="form-group col-md-2">
                            <select class="form-control">
                                <?php foreach ($offering as $of) : ?>
                                    <tr>
                                        <option><?= $of->year ?></option>
                                    </tr>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <h3 class="box-title pull-left"><strong>Term: </strong></h3>
                        <div class="form-group col-md-2">
                            <select class="form-control">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>

                        <button type="submit" class="btn btn-success" style="margin-left:10px;">Submit</button>
                    </div>
                </form>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <table class="table table-bordered table-responsive text-center">
                    <thead class="bg-success" style="background-color:#00a65a; color:white;">
                        <th class="text-center">COURSE</th>
                        <th class="text-center">SECTION</th>
                        <th class="text-center">REMAINING</th>
                        <th class="text-center">DAY</th>
                        <th class="text-center">TIME</th>
                    </thead>
                    <tbody>
                        <?php foreach ($offering as $of) : ?>
                            <tr>
                                <td><?= $of->course_code ?></td>
                                <td><?= $of->course_section ?></td>
                                <td><?= $of->course_slot ?></td>
                                <td>
                                    <?php foreach ($offeringSched as $ofs) : ?>
                                        <?php if ($of->course_code == $ofs->root_course && $of->course_section == $ofs->root_section) : ?>
                                            <?= $ofs->sched_day ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </td>

                                <td>

                                    <?php foreach ($offeringSched as $ofs) : ?>
                                        <?php if ($of->course_code == $ofs->root_course && $of->course_section == $ofs->root_section) : ?>
                                            <?= $ofs->sched_start . ' - ' . $ofs->sched_end . ' / ' ?>
                                        <?php endif; ?>
                                    <?php endforeach; ?>

                                </td>
                            </tr>

                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>


            <!-- /.box-body -->
        </div>
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->