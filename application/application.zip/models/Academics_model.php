<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Academics_model extends CI_Model
{

    public function fetchParallel()
    {
        $query = $this->db->get('parallel_tbl');
        return $query->result();
    }

    public function fetchParallelCourse()
    {
        $query = $this->db->get('parallel_course_tbl');
        return $query->result();
    }

    public function fetchOffering()
    {
        $query = $this->db->get('offering_tbl');
        return $query->result();
    }

    public function fetchOfferingSched()
    {
        $query = $this->db->get('offering_sched_tbl');
        return $query->result();
    }
}
