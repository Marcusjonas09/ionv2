<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Mobile_model extends CI_Model
{

    ///////////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////// MOBILE FUNCTIONS //////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////

    ///////////////////////////////////////////////////////////////////////////////////////////
    // LOGIN FUNCTIONS
    ///////////////////////////////////////////////////////////////////////////////////////////

    public function mobilelogin($user, $pass)
    {
        $this->db->where(array('acc_username' => $user, 'acc_password' => sha1($pass)));
        $query = $this->db->get('accounts_tbl');
        $user = $query->row();
        if ($query->num_rows() > 0) {
            if ($user->acc_access_level == 3) {
                $credentials = array(
                    'login' => true,
                    'acc_status' => $user->acc_status,
                    'acc_number' => $user->acc_number,
                    'Firstname' => $user->acc_fname,
                    'Lastname' => $user->acc_lname,
                    'Curriculum_code' => $user->curriculum_code
                );
                return $credentials;
            }
            return false;
        } else {
            return false;
        }
    }


    ///////////////////////////////////////////////////////////////////////////////////////////
    // ACCOUNT FUNCTIONS
    ///////////////////////////////////////////////////////////////////////////////////////////

    public function studentDetails($studNumber)
    {
        $query = $this->db->get_where('accounts_tbl', array('acc_number' => $studNumber));
        return $query->row();
    }

    public function fetchCurriculum($curriculum_code)
    {
        $this->db->select('*');
        $this->db->where(array('courses_tbl.curriculum_code' => $curriculum_code));
        $this->db->from('curriculum_tbl');
        $this->db->join('laboratory_tbl', 'laboratory_tbl.laboratory_id = curriculum_tbl.laboratory_id');
        $this->db->join('courses_tbl', 'courses_tbl.course_id = curriculum_tbl.course_id');
        $this->db->order_by('courses_tbl.course_code', 'ASC');
        $query = $this->db->get();
        return $query->result();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////
    // SERVICES FUNCTIONS
    ///////////////////////////////////////////////////////////////////////////////////////////

    ///////////////////////////////// PETITION FUNCTIONS //////////////////////////////////////

    public function fetchPetitions()
    {
        $query = $this->db->get('petitions_tbl');
        return $query->result();
    }

    public function fetchPetition($petitionID)
    {
        $query = $this->db->get_where('petitions_tbl', array('petition_ID' => $petitionID));
        return $query->row();
    }

    public function fetchPetitioners($course_code)
    {
        $this->db->select('*');
        $this->db->where(array('petition_code' => $course_code));
        $this->db->from('petitioners_tbl');
        $this->db->join('accounts_tbl', 'accounts_tbl.acc_number = petitioners_tbl.stud_number');
        $query = $this->db->get();
        return $query->result();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////
    // ACADEMICS FUNCTIONS
    ///////////////////////////////////////////////////////////////////////////////////////////

    public function fetchParallel()
    {
        $query = $this->db->get('parallel_tbl');
        return $query->result();
    }

    public function fetchParallelCourse()
    {
        $query = $this->db->get('parallel_course_tbl');
        return $query->result();
    }

    public function fetchOffering()
    {
        $query = $this->db->get('offering_tbl');
        return $query->result();
    }

    public function fetchOfferingDistinct()
    {
        $this->db->distinct();
        $this->db->select('course_code');
        $query = $this->db->get('offering_tbl');
        return $query->result();
    }

    public function fetchOfferingLab()
    {
        $query = $this->db->get('offering_lab_tbl');
        return $query->result();
    }

    public function fetchOfferingSched()
    {
        $query = $this->db->get('offering_sched_tbl');
        return $query->result();
    }

    ///////////////////////////////////////////////////////////////////////////////////////////
    // OTHER FUNCTIONS
    ///////////////////////////////////////////////////////////////////////////////////////////

    public function fetchAnnouncements()
    {
        $this->db->select('*');
        $this->db->from('posts_tbl');
        $this->db->join('accounts_tbl', 'accounts_tbl.acc_number = posts_tbl.post_account_id');
        $this->db->order_by('post_created', 'DESC');
        $query = $this->db->get();

        return $query->result();
    }

    public function sample($sample)
    {
        $data = array(
            'sample' => $sample
        );
        $this->db->insert('sample_tbl', $data);
        return json_encode(true);
    }

    public function submitPetition($petition)
    {
        $data = array(
            'stud_number' => 201610185,
            'course_code' => $petition
        );
        $this->db->insert('petitions_tbl', $data);
        return json_encode('data inserted');
    }

    public function signPetition($petition)
    {
        // return json_encode($petition['stud_number']);
        $data = array(
            'stud_number' => $petition['stud_number'],
            'petition_code' => $petition['petition_code']
        );
        $this->db->insert('petitioners_tbl', $data);
        return json_encode('Petition Signed!');
    }
}
