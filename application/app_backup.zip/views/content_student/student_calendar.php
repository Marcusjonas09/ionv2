<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <strong>Calendar</strong>
            
        </h1>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->