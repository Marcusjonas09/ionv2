<?php
$totalunits = 0;
$totalunitspassed = 0;
$course = 0;
$lab = 0;
$coursepassed = 0;
$labpassed = 0;
?>
<?php foreach ($progress as $unit) {
    $course += $unit->course_units;
    $lab += $unit->laboratory_units;
    foreach ($grades as $grade) {
        if ($unit->course_code == $grade->course_taken && $grade->grade > 0.0) {
            $coursepassed += $unit->course_units;
            $labpassed += $unit->laboratory_units;
        }
    }
}
$totalunits = $course + $lab;
$totalunitspassed = $coursepassed + $labpassed;
?>
<script src="https://rawgit.com/kimmobrunfeldt/progressbar.js/1.0.0/dist/progressbar.js"></script>



<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <strong>Dashboard</strong>
        </h1>
    </section>

    <!-- Main content -->
    <section class="content container-fluid">
        <div class="box box-success">
            <div class="box-header with-border">
                <h3 class="box-title"><strong>My Information</strong></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div class="row">
                    <div class="col-md-4">
                        <img class="profile-user-img img-responsive" src="<?= base_url() ?>dist/img/user1-128x128.jpg" style="width:200px; height:200px;" alt="User profile picture">
                    </div>
                    <div class="col-md-4">
                        <table class="table">
                            <tr>
                                <td><strong class="pull-right">Student Number : </strong></td>
                                <td><?= $stud_details->acc_number ?></td>
                            </tr>

                            <tr>
                                <td><strong class="pull-right">Name : </strong></td>
                                <td><?= $stud_details->acc_fname . ' ' . $stud_details->acc_mname . ' ' . $stud_details->acc_lname ?></td>
                            </tr>

                            <tr>
                                <td><strong class="pull-right">Citizenship : </strong></td>
                                <td><?= $stud_details->acc_citizenship ?></td>
                            </tr>

                            <tr>
                                <td><strong class="pull-right">Program : </strong></td>
                                <td><?= $stud_details->acc_program ?></td>
                            </tr>

                            <tr>
                                <td><strong class="pull-right">College : </strong></td>
                                <td><?= $stud_details->acc_college ?></td>
                            </tr>

                            <tr>
                                <td><strong class="pull-right">Curriculum Code : </strong></td>
                                <td><?= $stud_details->curriculum_code ?></td>
                            </tr>
                        </table>
                    </div>

                </div>
            </div>
            <!-- /.box-body -->
        </div>
        <div class="box box-success">
            <div class="box-header">
                <h3 class="box-title"><b>Student Progress</b></h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
                <div align="center" class="col-md-6">
                    <h4 class="text-center">Overall Progress</h4>
                    <div id="container"></div>
                </div>
                <div class="col-md-6">
                    <h4 class="text-center">Courses Enrolled</h4>
                </div>

            </div>
            <!-- /.box-body -->
        </div>
        <!-- /.box -->

    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<script>
    var progress = "<?php echo $totalunitspassed / $totalunits; ?>";
    var bar = new ProgressBar.Circle(container, {
        color: '#1f5',
        // This has to be the same size as the maximum width to
        // prevent clipping
        strokeWidth: 10,
        trailWidth: 7,
        easing: 'easeInOut',
        duration: 2000,
        text: {
            autoStyleContainer: false
        },
        from: {
            color: '#1f5',
            width: 10
        },
        to: {
            color: '#1f5',
            width: 10
        },
        // Set default step function for all animate calls
        step: function(state, circle) {
            circle.path.setAttribute('stroke', state.color);
            circle.path.setAttribute('stroke-width', state.width);

            var value = Math.round(circle.value() * 100);
            if (value === 0) {
                circle.setText('');
            } else {
                circle.setText(value + '%');
            }

        }
    });
    bar.text.style.fontFamily = '"Raleway", Helvetica, sans-serif';
    bar.text.style.fontSize = '2rem';

    bar.animate(progress); // Number from 0.0 to 1.0
</script>